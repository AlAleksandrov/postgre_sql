SELECT 
    p.title,
    CASE 
        WHEN pi.rating <= 3.50 THEN 'poor'
        WHEN pi.rating > 3.50 AND pi.rating <= 8.00 THEN 'good'
        ELSE 'excellent'
    END AS rating,
    CASE 
        WHEN pi.has_subtitles THEN 'Bulgarian'
        ELSE 'N/A'
    END AS subtitles,
    COUNT(pa.actor_id) AS actors_count
FROM 
    productions p
JOIN 
    productions_info pi ON p.production_info_id = pi.id
LEFT JOIN 
    productions_actors pa ON p.id = pa.production_id
GROUP BY 
    p.title, pi.rating, pi.has_subtitles
ORDER BY 
    rating ASC, 
    actors_count DESC, 
    p.title ASC;